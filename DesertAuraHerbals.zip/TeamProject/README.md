CIS 425 Group Project - CALS Tech (Team 4)

The public folder contains all of the client side assets - HTML, CSS, JS, and Images.

index.js is the node server code.

To Run:
Type "node server.js" in the terminal

If successful, you will see the following printed to the terminal:
Server started on port 3000
Connected to DB!
