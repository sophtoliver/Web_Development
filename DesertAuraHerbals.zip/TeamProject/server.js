// Packages
const express = require('express');
const mysql = require('mysql');

const app = express();
app.use(express.static('public'));

const dbConnObj = mysql.createConnection({
    host:     "sql.wpc-is.online", 
    user:     "cholmes8",
    password: "chol2658",
    database: "db_test_TeamB4"
});

dbConnObj.connect(function(error) {
    if (error) {
        console.log(error) // Prints error to terminal if DB connection is unsuccessful
    } else {
        console.log("Connected to DB!") // Prints message to terminal if DB connection is successful    
    };
});

app.get('/', function(req, res) {
    res.sendFile(__dirname + '/public/html/index.html');
});

app.get('/contact', function(req, res) {
    res.sendFile(__dirname + '/public/html/contact.html');
});

app.get('/products', function(req, res) {
    res.sendFile(__dirname + '/public/html/products.html');
});

// GET endpoint that allows the client-side JavaScript to fetch the data from the SQL databse as a JSON object
app.get('/fetchallproducts', function(req, res) {
    let query = "SELECT * FROM products";
    dbConnObj.query(query, function(error, dataSet, colSet) {
        if (error) {
            console.log(error)
        } else {
            res.send(dataSet); // Sends the queried data to the front-end as an array of JSON objects
        };
    });
});

let port = process.env.PORT;
if (port == null || port == "") {
    port = 3000;
};

app.listen(port, function() {
    console.log('Server started on port ' + port);
});