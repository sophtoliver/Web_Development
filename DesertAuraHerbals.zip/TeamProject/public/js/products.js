const app = document.getElementById('root');
const container = document.createElement('div');
container.setAttribute('class', 'container');
app.appendChild(container);

var subTotal = 0;
var tax = 0;
var shipping = 0;
var total = 0;
var items = 0;
var itemsInCart = [];

emptyCart();
requestData();

async function requestData() {
    try {
        const response = await fetch('/fetchallproducts');
        const data = await response.json();
        data.forEach((product) => {
            const card = document.createElement('div');
            card.setAttribute('class', 'card');
            const h1 = document.createElement('h1');
            h1.textContent = product.name;
            const p = document.createElement('p');
            p.setAttribute('id', 'product-description');
            p.textContent = product.description;  
            const h2 = document.createElement('h2');
            h2.textContent = product.price;
            const img = document.createElement('img');
            img.src = product.imageURL;
            const button = document.createElement('button');
            button.onclick = addToCart;
            button.innerHTML = 'Add To Cart';
            button.setAttribute('id', 'cart-button')
            container.appendChild(card);
            card.appendChild(h1);
            card.appendChild(img);
            card.appendChild(p);
            card.appendChild(h2);
            card.appendChild(button);
        });
    } catch (error) {
        alert('Error Fetching Products. Please Try Again.') // Alerts user that there is an error when requesting the products
    };
};



function addToCart() {
    var totalPrice = 0;
    items = items + 1;
    // Data is stored in the event object
    var price = event.path[1].childNodes[3].innerHTML;
    var name = event.path[1].childNodes[0].innerHTML;
    // productData is JSON object that is created to store product data and push it to the itemsInCart array
    var productData = {
        name: name,
        price: price
    };
    itemsInCart.push(productData);
    price = parseInt(price);
    subTotal = subTotal + price;
    tax = subTotal * .07;
    shipping = subTotal * .01;
    total = subTotal + tax + shipping;

    document.getElementById('total-items').innerHTML = 'Items In Cart: ' + items.toString();
    document.getElementById('sub-total').innerHTML = 'Sub-Total: $' + subTotal.toFixed(2);
    document.getElementById('tax-cost').innerHTML = 'Tax: $' + tax.toFixed(2);
    document.getElementById('shipping-cost').innerHTML = 'Shipping: $' + shipping.toFixed(2);
    document.getElementById('total-cost').innerHTML = 'Total: $' + total.toFixed(2);
}

function showCart() {

}

function emptyCart() {
    const cart = document.getElementById('cart-footer');
    subTotal = 0;
    items = 0;
    shipping = 0;
    tax = 0;
    total = 0;
    itemsInCart = [];
    document.getElementById('total-items').innerHTML = 'Items In Cart: ' + items.toString();
    document.getElementById('sub-total').innerHTML = 'Sub-Total: $' + subTotal.toFixed(2);
    document.getElementById('tax-cost').innerHTML = 'Tax: $' + tax.toFixed(2);
    document.getElementById('shipping-cost').innerHTML = 'Shipping: $' + shipping.toFixed(2);
    document.getElementById('total-cost').innerHTML = 'Total: $' + total.toFixed(2);
    var btn = document.createElement('button');
    btn.setAttribute('id', 'empty-cart-btn');
    btn.innerHTML = 'Empty Cart';
    btn.onclick = emptyCart;
    cart.appendChild(btn);
}