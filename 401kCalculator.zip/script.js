/*
 window.onload = function() {
  document.getElementById("calculate").onclick = processForm;
 }*/

window.onload = function() {
  document.getElementById("clear").onclick = clearForm;
}

function processForm() {
  var yearlyInterest = document.getElementById("dollarinvest").value;
  var interestRate = parseFloat(document.getElementById("interestrate").value);
  var numOfYears = parseInt(document.getElementById("numyears").value);


  var outputSection = document.getElementsByClassName("outputArea");

  if (interestRate > 1 && interestRate < 20) {
    if (numOfYears > 0 && numOfYears <= 10) {
      interestRate = interestRate / 100
      var numerator = (Math.pow(1 + interestRate, numOfYears)) - 1
    }
    else {
    alert("Number of years enetered must NOT exceed 10 years and must NOT be a negative amount of years")
    }
  }
  else {
    alert("Annual Interest Rate must be a value in the range 1 to 20. If your rate is 5% (i.e. 0.05), enter 5")
  }
  
  var futureValue = yearlyInterest * (numerator / interestRate)

  outputSection[0].innerHTML = "$" + futureValue.toFixed(2);

  document.getElementById("by-line").innerHTML = document.getElementById("by-line").innerHTML + " / Created By: Sophia Toliver (smtolive)"; 
}

function clearForm() {
  var yearlyInterest = document.getElementById("dollarinvest");
  yearlyInterest.selectedIndex = 0;
  document.getElementById("interestrate").value = ' ';
  document.getElementById("numyears").value = ' ';
  document.getElementsByClassName("outputArea").value = ' ';
}